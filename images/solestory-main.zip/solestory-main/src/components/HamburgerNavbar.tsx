import React, { useState } from 'react';
import { X } from 'lucide-react';

interface HamburgerNavbarProps {
  darkMode: boolean;
}

const HamburgerNavbar: React.FC<HamburgerNavbarProps> = ({ darkMode }) => {
  const [isOpen, setIsOpen] = useState(false);

  const navigationLinks = [
    { name: 'Home', href: '#home' },
    { name: 'Collection', href: '#collection' },
    { name: 'About', href: '#about' },
    { name: 'Contact', href: '#contact' }
  ];

  const toggleMenu = () => {
    setIsOpen(!isOpen);
  };

  return (
    <>
      {/* Hamburger Button */}
      <button
        onClick={toggleMenu}
        className="fixed top-6 right-6 z-50 p-4 rounded-full bg-white/90 dark:bg-gray-800/90 backdrop-blur-sm shadow-xl hover:shadow-2xl transition-all duration-300 border border-gray-200/50 dark:border-gray-700/50 hover:scale-110"
        aria-label="Toggle navigation"
      >
        <div className="relative w-6 h-6">
          {/* Hamburger Lines */}
          <span
            className={`absolute left-0 w-6 h-0.5 bg-gradient-to-r from-orange-500 to-violet-500 transition-all duration-300 ${
              isOpen ? 'top-3 rotate-45' : 'top-1'
            }`}
          />
          <span
            className={`absolute left-0 top-3 w-6 h-0.5 bg-gradient-to-r from-orange-500 to-violet-500 transition-all duration-300 ${
              isOpen ? 'opacity-0' : 'opacity-100'
            }`}
          />
          <span
            className={`absolute left-0 w-6 h-0.5 bg-gradient-to-r from-orange-500 to-violet-500 transition-all duration-300 ${
              isOpen ? 'top-3 -rotate-45' : 'top-5'
            }`}
          />
        </div>
      </button>

      {/* Side Navigation */}
      <nav
        className={`fixed top-0 right-0 h-full w-96 bg-white/95 dark:bg-gray-900/95 backdrop-blur-xl shadow-2xl transform transition-transform duration-700 ease-in-out z-40 border-l border-gray-200/50 dark:border-gray-700/50 ${
          isOpen ? 'translate-x-0' : 'translate-x-full'
        }`}
      >
        <div className="p-10 pt-24">
          <div className="mb-8">
            <h2 className="text-3xl font-light tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-orange-500 to-violet-600">
              Navigation
            </h2>
          </div>
          
          <ul className="space-y-8">
            {navigationLinks.map((link, index) => (
              <li key={link.name}>
                <a
                  href={link.href}
                  className="block text-2xl font-light text-gray-700 dark:text-gray-300 hover:text-transparent hover:bg-clip-text hover:bg-gradient-to-r hover:from-orange-500 hover:to-violet-600 transition-all duration-300 py-3 tracking-wide"
                  onClick={() => setIsOpen(false)}
                  style={{
                    animationDelay: `${index * 0.1}s`
                  }}
                >
                  {link.name}
                </a>
              </li>
            ))}
          </ul>
        </div>
      </nav>

      {/* Overlay */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-black/60 backdrop-blur-sm z-30 transition-all duration-700"
          onClick={toggleMenu}
        />
      )}
    </>
  );
};

export default HamburgerNavbar;