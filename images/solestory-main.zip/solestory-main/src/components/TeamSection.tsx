import React, { useState } from 'react';

interface TeamSectionProps {
  darkMode: boolean;
}

interface TeamMember {
  id: number;
  name: string;
  role: string;
  image: string;
}

const TeamSection: React.FC<TeamSectionProps> = ({ darkMode }) => {
  const [hoveredMember, setHoveredMember] = useState<number | null>(null);

  const teamMembers: TeamMember[] = [
    {
      id: 1,
      name: 'Alex Johnson',
      role: 'Creative Director',
      image: 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=400'
    },
    {
      id: 2,
      name: 'Sarah Chen',
      role: 'Lead Designer',
      image: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=400'
    },
    {
      id: 3,
      name: 'Marcus Thompson',
      role: 'Product Manager',
      image: 'https://images.pexels.com/photos/2182970/pexels-photo-2182970.jpeg?auto=compress&cs=tinysrgb&w=400'
    },
    {
      id: 4,
      name: 'Emily Rodriguez',
      role: 'Brand Strategist',
      image: 'https://images.pexels.com/photos/1130626/pexels-photo-1130626.jpeg?auto=compress&cs=tinysrgb&w=400'
    }
  ];

  return (
    <div className="relative">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
        {teamMembers.map((member) => (
          <div
            key={member.id}
            className="relative text-center group"
            onMouseEnter={() => setHoveredMember(member.id)}
            onMouseLeave={() => setHoveredMember(null)}
          >
            <div className="relative">
              <h3 className="text-2xl font-light tracking-wide text-gray-900 dark:text-white mb-3 cursor-pointer hover:text-transparent hover:bg-clip-text hover:bg-gradient-to-r hover:from-orange-500 hover:to-violet-600 transition-all duration-300">
                {member.name}
              </h3>
              <p className="text-gray-600 dark:text-gray-400 font-light tracking-wide">
                {member.role}
              </p>
              
              {/* Profile Image Pop-up */}
              {hoveredMember === member.id && (
                <div className="absolute top-full left-1/2 transform -translate-x-1/2 mt-6 z-10 animate-fadeInUp">
                  <div className="relative">
                    <img
                      src={member.image}
                      alt={member.name}
                      className="w-40 h-40 rounded-2xl object-cover shadow-2xl border-4 border-white dark:border-gray-700 transform hover:scale-105 transition-transform duration-300"
                    />
                    {/* Gradient border effect */}
                    <div className="absolute inset-0 rounded-2xl bg-gradient-to-r from-orange-400 via-pink-400 to-violet-400 p-1 -z-10">
                      <div className="w-full h-full rounded-2xl bg-white dark:bg-gray-800"></div>
                    </div>
                    {/* Arrow pointing up */}
                    <div className="absolute -top-3 left-1/2 transform -translate-x-1/2 w-0 h-0 border-l-10 border-r-10 border-b-10 border-l-transparent border-r-transparent border-b-white dark:border-b-gray-700"></div>
                  </div>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default TeamSection;