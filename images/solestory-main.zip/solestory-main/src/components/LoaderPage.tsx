import React from 'react';

const LoaderPage: React.FC = () => {
  return (
    <div className="fixed inset-0 bg-gradient-to-br from-gray-900 via-violet-900 to-orange-900 flex items-center justify-center z-50">
      <div className="text-center">
        <h1 className="text-8xl md:text-9xl lg:text-[12rem] font-light tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-orange-400 via-pink-400 to-violet-400 mb-8 animate-pulse">
          Solestory
        </h1>
        <p className="text-xl md:text-2xl font-light tracking-widest text-white/90 mb-12 uppercase animate-pulse">
          Step into what's next
        </p>
        <div className="flex items-center justify-center space-x-3 mb-8">
          <div className="w-4 h-4 bg-gradient-to-r from-orange-400 to-pink-500 rounded-full animate-bounce"></div>
          <div className="w-4 h-4 bg-gradient-to-r from-pink-400 to-violet-500 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
          <div className="w-4 h-4 bg-gradient-to-r from-violet-400 to-blue-500 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
        </div>
        <p className="text-white/70 text-lg font-light tracking-wider animate-pulse">Loading...</p>
      </div>
    </div>
  );
};

export default LoaderPage;