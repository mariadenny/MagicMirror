import React, { useState, useRef } from 'react';

interface ImageGridProps {
  darkMode: boolean;
}

const ImageGrid: React.FC<ImageGridProps> = ({ darkMode }) => {
  const [ripples, setRipples] = useState<{ [key: string]: { x: number; y: number; id: number } | null }>({});
  const gridRef = useRef<HTMLDivElement>(null);

  const shoes = [
    {
      id: 1,
      src: 'https://images.pexels.com/photos/2529148/pexels-photo-2529148.jpeg?auto=compress&cs=tinysrgb&w=800',
      alt: 'Nike Air Max'
    },
    {
      id: 2,
      src: 'https://images.pexels.com/photos/1598505/pexels-photo-1598505.jpeg?auto=compress&cs=tinysrgb&w=800',
      alt: 'Adidas Ultraboost'
    },
    {
      id: 3,
      src: 'https://images.pexels.com/photos/1464625/pexels-photo-1464625.jpeg?auto=compress&cs=tinysrgb&w=800',
      alt: 'Converse Chuck Taylor'
    },
    {
      id: 4,
      src: 'https://images.pexels.com/photos/267301/pexels-photo-267301.jpeg?auto=compress&cs=tinysrgb&w=800',
      alt: 'Vans Old Skool'
    },
    {
      id: 5,
      src: 'https://images.pexels.com/photos/1598508/pexels-photo-1598508.jpeg?auto=compress&cs=tinysrgb&w=800',
      alt: 'Puma Suede'
    },
    {
      id: 6,
      src: 'https://images.pexels.com/photos/2300334/pexels-photo-2300334.jpeg?auto=compress&cs=tinysrgb&w=800',
      alt: 'Reebok Classic'
    }
  ];

  const handleMouseMove = (e: React.MouseEvent, shoeId: number) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    
    setRipples(prev => ({
      ...prev,
      [shoeId]: { x, y, id: Date.now() }
    }));
  };

  const handleMouseLeave = (shoeId: number) => {
    setRipples(prev => ({
      ...prev,
      [shoeId]: null
    }));
  };

  return (
    <div 
      ref={gridRef}
      className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
    >
      {shoes.map((shoe) => (
        <div
          key={shoe.id}
          className="relative group cursor-pointer overflow-hidden rounded-2xl bg-gradient-to-br from-gray-100 to-gray-200 dark:from-gray-800 dark:to-gray-900 shadow-lg hover:shadow-2xl transition-all duration-500"
          onMouseMove={(e) => handleMouseMove(e, shoe.id)}
          onMouseLeave={() => handleMouseLeave(shoe.id)}
        >
          <div className="aspect-square overflow-hidden relative">
            <img
              src={shoe.src}
              alt={shoe.alt}
              className="w-full h-full object-cover transition-all duration-700 group-hover:scale-110 group-hover:brightness-110"
            />
            
            {/* Gradient Overlay */}
            <div className="absolute inset-0 bg-gradient-to-t from-black/20 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
          </div>
          
          {/* Ripple Effect */}
          {ripples[shoe.id] && (
            <div
              className="absolute pointer-events-none"
              style={{
                left: ripples[shoe.id]!.x - 50,
                top: ripples[shoe.id]!.y - 50,
                width: 100,
                height: 100,
              }}
            >
              <div className="w-full h-full rounded-full bg-gradient-to-r from-orange-400/30 via-pink-400/30 to-violet-400/30 animate-ping"></div>
            </div>
          )}
          
          {/* Overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/0 group-hover:from-black/40 via-transparent to-transparent transition-all duration-500 flex items-end">
            <div className="p-6 text-white opacity-0 group-hover:opacity-100 transition-all duration-500 transform translate-y-4 group-hover:translate-y-0">
              <h3 className="font-light text-xl tracking-wide">{shoe.alt}</h3>
              <p className="text-sm text-white/80 mt-1 font-light">Premium Collection</p>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default ImageGrid;