import React from 'react';

interface InfiniteMarqueeProps {
  darkMode: boolean;
}

const InfiniteMarquee: React.FC<InfiniteMarqueeProps> = ({ darkMode }) => {
  const brands = ['NIKE', 'ADIDAS', 'PUMA', 'REEBOK', 'VANS', 'CONVERSE', 'NEW BALANCE', 'JORDAN'];
  const marqueeText = brands.join(' • ') + ' • ';

  return (
    <div className="overflow-hidden bg-gradient-to-r from-orange-500 via-pink-500 to-violet-600 py-6 relative">
      {/* Animated background pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent animate-shimmer"></div>
      </div>
      
      <div className="flex animate-marquee whitespace-nowrap">
        <span className="text-3xl md:text-5xl font-light tracking-widest text-white mx-8 drop-shadow-lg">
          {marqueeText}
        </span>
        <span className="text-3xl md:text-5xl font-light tracking-widest text-white mx-8 drop-shadow-lg">
          {marqueeText}
        </span>
        <span className="text-3xl md:text-5xl font-light tracking-widest text-white mx-8 drop-shadow-lg">
          {marqueeText}
        </span>
      </div>
    </div>
  );
};

export default InfiniteMarquee;