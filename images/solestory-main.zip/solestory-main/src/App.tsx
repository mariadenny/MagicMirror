import React, { useState, useEffect } from 'react';
import LoaderPage from './components/LoaderPage';
import ImageGrid from './components/ImageGrid';
import HamburgerNavbar from './components/HamburgerNavbar';
import InfiniteMarquee from './components/InfiniteMarquee';
import TeamSection from './components/TeamSection';
import { Moon, Sun } from 'lucide-react';

function App() {
  const [loading, setLoading] = useState(true);
  const [darkMode, setDarkMode] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => {
      setLoading(false);
    }, 4000); // Extended to 4 seconds for better visibility

    return () => clearTimeout(timer);
  }, []);

  const toggleDarkMode = () => {
    setDarkMode(!darkMode);
  };

  if (loading) {
    return <LoaderPage />;
  }

  return (
    <div className={`min-h-screen transition-colors duration-300 ${darkMode ? 'dark bg-gray-900' : 'bg-white'}`}>
      <HamburgerNavbar darkMode={darkMode} />
      
      {/* Dark/Light Mode Toggle */}
      <button
        onClick={toggleDarkMode}
        className="fixed top-4 left-4 z-50 p-3 rounded-full bg-white dark:bg-gray-800 shadow-lg hover:shadow-xl transition-all duration-300 border border-gray-200 dark:border-gray-700"
      >
        {darkMode ? (
          <Sun className="w-5 h-5 text-yellow-500" />
        ) : (
          <Moon className="w-5 h-5 text-gray-700" />
        )}
      </button>

      {/* Hero Section */}
      <section className="pt-20 pb-16 px-4">
        <div className="max-w-6xl mx-auto text-center">
          <h1 className="text-6xl md:text-8xl lg:text-9xl font-light tracking-tight text-gray-900 dark:text-white mb-6 leading-none">
            Solestory
          </h1>
          <p className="text-2xl md:text-3xl font-light tracking-wide text-transparent bg-clip-text bg-gradient-to-r from-orange-500 via-pink-500 to-violet-600 mb-16 uppercase letter-spacing-wide">
            Step into what's next.
          </p>
          
          {/* Floating Elements */}
          <div className="absolute top-1/4 left-10 w-20 h-20 bg-gradient-to-br from-orange-400 to-pink-500 rounded-full opacity-20 animate-float"></div>
          <div className="absolute top-1/3 right-16 w-12 h-12 bg-gradient-to-br from-violet-400 to-blue-500 rounded-full opacity-30 animate-float-delayed"></div>
          <div className="absolute bottom-1/4 left-1/4 w-8 h-8 bg-gradient-to-br from-pink-400 to-orange-500 rounded-full opacity-25 animate-float-slow"></div>
        </div>
      </section>

      {/* Image Grid Section */}
      <section className="py-16 px-4">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-8 text-center">
            Featured Collection
          </h2>
          <ImageGrid darkMode={darkMode} />
        </div>
      </section>

      {/* Infinite Marquee */}
      <section className="py-16">
        <InfiniteMarquee darkMode={darkMode} />
      </section>

      {/* Team Section */}
      <section className="py-16 px-4">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-8 text-center">
            Our Team
          </h2>
          <TeamSection darkMode={darkMode} />
        </div>
      </section>
    </div>
  );
}

export default App;